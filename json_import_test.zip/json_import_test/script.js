function fetchData()
{
    fetch('filmdata.json')
    .then(response => {
        if (!response.ok) {
            throw new Error("Http error" + response.status)
        }
        return response.json();
    })
    .then(data => createMovies(data))
    .catch(error => console.error("failed to fetch data", error))
}
fetchData();

function createMovie(film) {
    return `
    <div class="image_div">
        <img src="${film.images.base}"></img>
    </div>`;
}

const moviediv = document.getElementById("image_test");

function createMovies(data)
{
    console.log("wtf!!")
    for (let i = 0; i < data.film.length; i++)
    {
        moviediv.innerHTML += createMovie(data.film[i])
    }
}